package boundary;

public class CommonUI {
    public static void displaySingleMessage(String message) {
        System.out.println(message);
    }
}
