 module SC2002Assignment {
	requires java.base;
}